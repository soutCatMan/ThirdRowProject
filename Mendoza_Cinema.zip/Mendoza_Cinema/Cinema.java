

/*
	Autore : Giancarlo Mendoza
	Testo: Si vuole creare un'applicazione di prenotazione dei posti di un cinema. 
	Per cio, creare una mappa interattiva dei posti di un cinema composta da 20 file e 16 posti per fila. 
	Il colore determina se il posto e libero o e gia stato occupato. il posto puo essere occupato con un semplice click. 
	Da qualche parte dell'interfaccia ci sara un riepilogo dei posti occupati con una scritta riassuntiva.
*/


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Cinema{
	JButton btnPosti[][];
	JTextArea txaPosti;
	JPanel pnlPosti;
	JPanel pnlSegnaPosti;
	
	public Cinema(){
		
		char alfabet[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S','T'};
		int num[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
		int i,j;
		btnPosti = new JButton[20][16];
		
		//JFrame 
		JFrame f = new JFrame("Cinema");
		
		//JPanel + Bottoni 
		pnlPosti = new JPanel();
		pnlPosti.setLayout(new GridLayout(20, 16));
		for(i=0; i<alfabet.length; i++){
			for(j=0; j<num.length; j++){
			btnPosti[i][j]= new JButton(alfabet[i]+" - "+num[j]);
			btnPosti[i][j].setBackground(Color.WHITE);
			pnlPosti.add(btnPosti[i][j]);
			}
		}
		
		//JPanel  e TextArea
		pnlSegnaPosti = new JPanel();
		pnlSegnaPosti.setLayout(new GridLayout(1, 20));
		txaPosti = new JTextArea("Posti Occupati:\n",1,20);
		txaPosti.setEditable(false);
		pnlSegnaPosti.add(txaPosti);
		
		//font
		Font font = new Font("Arial", Font.PLAIN,14);
		for(i=0; i<alfabet.length; i++){
			for(j=0; j<num.length; j++){
				btnPosti[i][j].setFont(font);
			}
		}
		txaPosti.setFont(font);
		
		
		f.add(pnlPosti,"Center");
		f.add(pnlSegnaPosti,"East");
		
		//Eventi
		ClicBottone clicBottone =new ClicBottone();
		for(i=0; i<alfabet.length; i++){
			for(j=0; j<num.length; j++){
				btnPosti[i][j].addActionListener(clicBottone);
			}
		}
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(600,700);
		f.setVisible(true);
	}

	public class ClicBottone implements ActionListener{
		public void actionPerformed(ActionEvent e){
			JButton btnClic = (JButton) e.getSource();
			if(btnClic.getBackground() == Color.WHITE){
				btnClic.setBackground(Color.lightGray); 
				txaPosti.append(btnClic.getText()+"\n");
			}else{
				btnClic.setBackground(Color.WHITE);
				txaPosti.setText(txaPosti.getText().replace(btnClic.getText() + "\n", ""));
			}
			
		}
	}
	
	
	public static void main(String[] args) {
		new Cinema();
	}
}



